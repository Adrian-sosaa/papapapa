# UIII_p1_Tabla_Materia_5J
- ![image](https://github.com/user-attachments/assets/f90b92ec-6c6e-498d-9487-965267752be7)
- ![image](https://github.com/user-attachments/assets/99b14b3b-e34d-490f-b2d7-170559e0b1ba)



